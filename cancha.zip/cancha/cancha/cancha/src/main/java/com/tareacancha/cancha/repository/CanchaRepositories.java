package com.tareacancha.cancha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tareacancha.cancha.entites.Cancha;

public interface CanchaRepositories extends JpaRepository<Cancha, Integer> {

    


}
