package com.tareacancha.cancha.entites;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "cancha")
@NoArgsConstructor
@AllArgsConstructor
@Data 
public class Cancha {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    private String nombre;
    
    private String tipo;
    
    private Integer precioporhora; 

}