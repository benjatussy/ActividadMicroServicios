package com.tareacancha.cancha.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.tareacancha.cancha.repository.CanchaRepositories; 
import com.tareacancha.cancha.entites.Cancha;
import java.util.List; 

@Service
public class CanchaServices {

    @Autowired
    private CanchaRepositories canchaRepository; 
    public List<Cancha> listarTodas() {
        return canchaRepository.findAll(); 
    }

    public Cancha guardar(Cancha cancha) {
        return canchaRepository.save(cancha);
    }
}