package com.tareacancha.cancha.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tareacancha.cancha.entites.Cancha;
import com.tareacancha.cancha.repository.CanchaRepositories;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



@RequestMapping("api/canchas")
@RestController
public class CachaController {

    @Autowired
    private CanchaRepositories canchaRepository;

    @GetMapping
    public List<Cancha> listarTodas() {
        return canchaRepository.findAll();
    }

    @PostMapping
    public Cancha crear(@RequestBody Cancha cancha) {
        return canchaRepository.save(cancha);
    }
    

    
}
