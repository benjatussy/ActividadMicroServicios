package com.tareacancha.cancha.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tareacancha.cancha.entites.Cancha;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RequestMapping("api/canchas")
@RestController
public class CachaController {

    private List<Cancha> listaCanchas = new ArrayList<>(); 
    // 1. Definimos un contador que inicia en 1
    private final AtomicLong idGenerator = new AtomicLong(1);

    @GetMapping
    public ResponseEntity<List<Cancha>> listarCanchas() {
        return ResponseEntity.ok(listaCanchas);
    }
   
    


    @PostMapping
    public Cancha crearCancha(@RequestBody Cancha nuevaCancha) {
        // Generamos el ID y lo asignamos a la entidad
        Long idAsignado = idGenerator.getAndIncrement();
        nuevaCancha.setId(idAsignado);
        
        // Guardamos en nuestra lista en memoria
        listaCanchas.add(nuevaCancha);
        
        return nuevaCancha;
    }
}
