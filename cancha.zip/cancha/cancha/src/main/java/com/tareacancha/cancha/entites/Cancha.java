package com.tareacancha.cancha.entites;


public class Cancha {

    private Long id;
    private String nombre;
    private String tipo;
    private Long precioPorHora;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    
    public Cancha() {
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public Long getPrecioPorHora() {
        return precioPorHora;
    }
    public void setPrecioPorHora(Long precioPorHora) {
        this.precioPorHora = precioPorHora;
    }


    


}
