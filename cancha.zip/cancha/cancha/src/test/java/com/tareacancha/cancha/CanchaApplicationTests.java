package com.tareacancha.cancha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CanchaApplicationTests {

	@Test
	void contextLoads() {
	}

}
