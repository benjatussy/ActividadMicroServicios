package com.reserva.api.entities;

import java.sql.Time;
import java.util.Date;

public class Reservas {

    private Long canchaid;
    private String nombreCliente;
    private Date fecha;
    private Time horaInicio;
    private Time horaFin;
    
    public Reservas() {
    }

    public Long getCanchaid() {
        return canchaid;
    }

    public void setCanchaid(Long canchaid) {
        this.canchaid = canchaid;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Time horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Time getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(Time horaFin) {
        this.horaFin = horaFin;
    }

    
    
}
