package com.reserva.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reserva.api.entities.Reservas;

public interface ReservasRepository extends JpaRepository<Reservas, Long> {
    List<Reservas> findByCanchaid(Long canchaid);
}
