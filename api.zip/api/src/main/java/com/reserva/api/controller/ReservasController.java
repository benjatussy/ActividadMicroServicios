package com.reserva.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reserva.api.entities.Reservas;
import com.reserva.api.repository.ReservasRepository;

@RestController
@RequestMapping("api/reservas")
public class ReservasController {

    @Autowired
    private ReservasRepository repository;

    @GetMapping
    public List<Reservas> listarTodas() {
        return repository.findAll();
    }


    @PostMapping
    public Reservas crearReserva(@RequestBody Reservas reserva) {
        return repository.save(reserva);
    }


    @GetMapping("/{id}")
    public List<Reservas> listarPorCancha(@PathVariable() Long id) {
        return repository.findByCanchaid(id);
    }

}
