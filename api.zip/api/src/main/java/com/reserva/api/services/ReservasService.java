package com.reserva.api.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reserva.api.entities.Reservas;
import com.reserva.api.repository.ReservasRepository;

@Service
public class ReservasService {
    
    @Autowired
    private ReservasRepository repository;

    public List<Reservas> obtenerTodas() {
        return repository.findAll();
    }

    
    public Reservas guardarReserva(Reservas reserva) {
        if (reserva.getHoraInicio().isAfter(reserva.getHoraFin())) {
            throw new IllegalArgumentException("La hora de inicio no puede ser posterior a la de fin.");
        }
        return repository.save(reserva);
    }

    public List<Reservas> obtenerPorCancha(Long canchaId) {
        return repository.findByCanchaid(canchaId);
    }
}
