package com.reserva.api.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reserva.api.entities.Reservas;

@RestController
@RequestMapping("api/reservas")
public class ReservaController {

    private List<Reservas> listaReservas = new ArrayList<>();

    private final AtomicLong contadorCanchas = new AtomicLong(1);
    @GetMapping
    public ResponseEntity<List<Reservas>> obtenerTodas() {
        return ResponseEntity.ok(listaReservas);
    }


    @GetMapping("/{id}")
    public ResponseEntity<Reservas> obtenerPorId(@PathVariable Long id) {
        return listaReservas.stream()
                .filter(reserva -> reserva.getCanchaid().equals(id))
                .findFirst()
                .map(reserva -> ResponseEntity.ok(reserva)) 
                .orElse(ResponseEntity.notFound().build()); 
    }

    @PostMapping
    public ResponseEntity<Reservas> crearReserva(@RequestBody Reservas nuevaReserva) {
        nuevaReserva.setCanchaid(contadorCanchas.getAndIncrement());
        listaReservas.add(nuevaReserva);
        return new ResponseEntity<>(nuevaReserva, HttpStatus.CREATED);
    }

}
